<?php
/**
 * Created by PhpStorm.
 * User: admin
 * Date: 05.01.2017
 * Time: 12:47
 */

namespace app\controllers;

use yii\web\Controller;

class AppController extends Controller
{

}