<?php

echo 2+5+1;






