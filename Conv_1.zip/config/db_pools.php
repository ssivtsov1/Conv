<?php
return [
    'class' => 'yii\db\Connection',
    'dsn' => 'mysql:host=192.168.55.10;dbname=polls',
    'username' => 'ssivtcov',
    'password' => 'bpkextybt',
    'charset' => 'utf8',
];