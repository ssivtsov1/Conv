<?php


return [
    'class' => 'yii\db\Connection',
    'dsn' => 'pgsql:host=192.168.85.1;port=5432;dbname=energo_apres',
    'username' => 'local',
    'password' => '',
    'charset' => 'utf8',
];


