<?php


return [
    'class' => 'yii\db\Connection',
    'dsn' => 'pgsql:host=192.168.55.16;port=5432;dbname=energo_pvres',
    'username' => 'local',
    'password' => '',
    'charset' => 'utf8',
];


