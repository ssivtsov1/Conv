<?php
return [
    'class' => 'yii\db\Connection',
    'dsn' => 'mysql:host=localhost;dbname=snab',
    'username' => 'snab',
    'password' => 'XnSayCc5T7YjudNh',
    'charset' => 'utf8',
];