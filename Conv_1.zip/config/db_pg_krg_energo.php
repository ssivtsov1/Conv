<?php


return [
    'class' => 'yii\db\Connection',
    'dsn' => 'pgsql:host=192.168.75.1;port=5432;dbname=energo_krgres',
    'username' => 'local',
    'password' => '',
    'charset' => 'utf8',
];


