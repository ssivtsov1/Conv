<?php


return [
    'class' => 'yii\db\Connection',
    'dsn' => 'pgsql:host=172.16.55.1;port=5432;dbname=energo_pvres',
    'username' => 'local',
    'password' => '',
    'charset' => 'utf8',
];


