<?php


return [
    'class' => 'yii\db\Connection',
    'dsn' => 'pgsql:host=localhost;port=5432;dbname=im_db',
    'username' => 'local',
    'password' => '',
    'charset' => 'utf8',
];


