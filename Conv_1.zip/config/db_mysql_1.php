<?php
$_fn=realpath(__DIR__."/../data")."/data.db";
return [
    'class' => 'yii\db\Connection',
    'dsn' => 'mysql:host=192.168.55.16;dbname=snab',
    'username' => 'ssivtcov',
    'password' => 'ndjhxtcndj',
    'charset' => 'utf8',
];
