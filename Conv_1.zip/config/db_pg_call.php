<?php


return [
    'class' => 'yii\db\Connection',
    'dsn' => 'pgsql:host=192.168.54.7;port=5432;dbname=cek',
    'username' => 'ssivtcov',
    'password' => 'bpkextybt',
    'charset' => 'utf8',
];


