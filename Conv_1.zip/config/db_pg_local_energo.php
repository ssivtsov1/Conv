<?php


return [
    'class' => 'yii\db\Connection',
    'dsn' => 'pgsql:host=localhost;port=5432;dbname=energo',
    'username' => 'local',
    'password' => '',
    'charset' => 'utf8',
];


