<?php


return [
    'class' => 'yii\db\Connection',
    'dsn' => 'pgsql:host=192.168.17.1;port=5432;dbname=abn_gv',
    'username' => 'local',
    'password' => '',
    'charset' => 'utf8',
];


