<?php
$_fn=realpath(__DIR__."/../data")."/data.db";
return [
    'class' => 'yii\db\Connection',
    'dsn' => 'mysql:host=localhost;dbname=connect',
    'username' => 'connect',
    'password' => 'nhfycajhvfnjh',
    'charset' => 'utf8',
];
