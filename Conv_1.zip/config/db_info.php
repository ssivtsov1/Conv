<?php
return [
    'class' => 'yii\db\Connection',
    'dsn' => 'mysql:host=localhost;dbname=info',
    'username' => 'info',
    'password' => '[hjyjkjubz',
    'charset' => 'utf8',
];