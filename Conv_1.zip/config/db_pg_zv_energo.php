<?php


return [
    'class' => 'yii\db\Connection',
    'dsn' => 'pgsql:host=192.168.26.1;port=5432;dbname=energo',
    'username' => 'local',
    'password' => '',
    'charset' => 'utf8',
];


