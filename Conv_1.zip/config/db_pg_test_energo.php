<?php


return [
    'class' => 'yii\db\Connection',
    'dsn' => 'pgsql:host=192.168.55.16;port=5432;dbname=test3',
    'username' => 'local',
    'password' => '',
    'charset' => 'utf8',
];


