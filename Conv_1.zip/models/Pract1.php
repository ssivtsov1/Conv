<?php


namespace app\models;

//use Yii;
use yii\base\Model;

/**
 * Форма ввода данных для решения задач
 */
class Pract1 extends Model
{
    public $str='' ;
    public $passwd='' ;

    
       public function rules()
    {
        return [
           
            [['str'], 'required'],
            [['passwd'], 'safe'],
            
        ];
    }

    public function task1($a,$b)
    {
        return $a+$b;
    }
 
}

